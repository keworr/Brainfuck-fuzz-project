#!/bin/bash
for (( count=12698280; 2>1; count++ ))
do
rm $(echo "$count").bf
done
